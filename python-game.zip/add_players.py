"""Add additional players to stats table so user can pick full XI."""
import fantasy_cricket.db as db

extra = [
    ('Ajinkya Rahane', 'BAT', 80, 160, 4500, 4, 27),
    ('Yuvraj Singh', 'BAT', 85, 304, 8701, 14, 52),
    ('Suresh Raina', 'BAT', 78, 226, 5615, 5, 36),
    ('Shreyas Iyer', 'BAT', 75, 60, 2000, 0, 16),
    ('Mohammed Shami', 'BOW', 88, 100, 80, 0, 0),
    ('Yuzvendra Chahal', 'BOW', 82, 70, 50, 0, 0),
    ('Kuldeep Yadav', 'BOW', 79, 60, 40, 0, 0),
    ('Umesh Yadav', 'BOW', 77, 100, 75, 0, 0),
    ('Axar Patel', 'AR', 83, 67, 208, 0, 2),
    ('Kedar Jadhav', 'AR', 80, 73, 1385, 0, 6),
    ('Rishabh Pant', 'WK', 84, 30, 900, 2, 5),
    ('Dinesh Karthik', 'WK', 78, 94, 1752, 0, 9),
]

conn = db.get_connection()
cur = conn.cursor()
cur.executemany(
    'INSERT OR IGNORE INTO stats (player, ctg, value, matches, runs, hundreds, fifties) VALUES (?,?,?,?,?,?,?)',
    extra
)
conn.commit()
conn.close()
print('Added', len(extra), 'extra players.')
