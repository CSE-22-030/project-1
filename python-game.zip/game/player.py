import pygame

class Player:
    def __init__(self, screen):
        self.screen = screen
        self.width = 50
        self.height = 50
        self.x = screen.get_width() // 2
        self.y = screen.get_height() - 100
        self.speed = 5
        self.color = (0, 255, 0)
        
    def move(self, keys):
        if keys[pygame.K_LEFT] and self.x > 0:
            self.x -= self.speed
        if keys[pygame.K_RIGHT] and self.x < self.screen.get_width() - self.width:
            self.x += self.speed
        if keys[pygame.K_UP] and self.y > 0:
            self.y -= self.speed
        if keys[pygame.K_DOWN] and self.y < self.screen.get_height() - self.height:
            self.y += self.speed
        
    def draw(self):
        pygame.draw.rect(self.screen, self.color, (self.x, self.y, self.width, self.height))
