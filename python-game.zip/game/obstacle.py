import pygame
import random

class Obstacle:
    def __init__(self, screen):
        self.screen = screen
        self.width = 30
        self.height = 30
        self.x = random.randint(0, screen.get_width() - self.width)
        self.y = -self.height
        self.speed = 3
        self.color = (255, 0, 0)
        
    def update(self):
        self.y += self.speed
        return self.y > self.screen.get_height()
        
    def draw(self):
        pygame.draw.rect(self.screen, self.color, (self.x, self.y, self.width, self.height))
