import pygame
from .player import Player
from .obstacle import Obstacle

class Game:
    def __init__(self, screen):
        self.screen = screen
        self.running = True
        self.clock = pygame.time.Clock()
        self.FPS = 60
        
        # Game state initialization
        self.player = Player(screen)
        self.obstacles = []
        self.score = 0
        self.obstacle_timer = 0
        self.obstacle_spawn_rate = 60  # spawn obstacle every 60 frames
        
        # Assets
        self.font = pygame.font.Font(None, 36)
        
    def handle_events(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                self.running = False
        
    def update(self):
        # Get keyboard state for player movement
        keys = pygame.key.get_pressed()
        self.player.move(keys)
        
        # Update obstacles and spawn new ones
        self.obstacle_timer += 1
        if self.obstacle_timer >= self.obstacle_spawn_rate:
            self.obstacles.append(Obstacle(self.screen))
            self.obstacle_timer = 0
        
        # Update existing obstacles
        for obstacle in self.obstacles[:]:  # iterate over copy
            if obstacle.update():  # returns True if obstacle is off screen
                self.obstacles.remove(obstacle)
                self.score += 1
            
            # Check collision with player
            if self.check_collision(self.player, obstacle):
                self.running = False
        
    def draw(self):
        # Clear screen
        self.screen.fill((0, 0, 0))
        
        # Draw player
        self.player.draw()
        
        # Draw obstacles
        for obstacle in self.obstacles:
            obstacle.draw()
        
        # Draw score
        score_text = self.font.render(f"Score: {self.score}", True, (255, 255, 255))
        self.screen.blit(score_text, (10, 10))
        
    def check_collision(self, player, obstacle):
        player_rect = pygame.Rect(player.x, player.y, player.width, player.height)
        obstacle_rect = pygame.Rect(obstacle.x, obstacle.y, obstacle.width, obstacle.height)
        return player_rect.colliderect(obstacle_rect)
