"""Populate the fantasy_cricket.match table with a small demo scorecard."""
import fantasy_cricket.db as db

rows = [
    # name, player, scored, faced, fours, sixes, bowled(balls), maiden, given, wkts, catches, stumping, run_out
    ('Match1', 'Virat Kohli', 102, 98, 8, 2, 0, 0, 0, 0, 0, 0, 0),
    ('Match1', 'Rohit Sharma', 46, 65, 5, 1, 0, 0, 0, 0, 0, 0, 0),
    ('Match1', 'Shikhar Dhawan', 32, 35, 4, 0, 0, 0, 0, 0, 0, 0, 0),
    ('Match1', 'KL Rahul', 35, 30, 3, 1, 0, 0, 0, 0, 1, 0, 0),
    ('Match1', 'MS Dhoni', 56, 45, 3, 0, 0, 0, 0, 0, 2, 1, 0),
    ('Match1', 'Hardik Pandya', 42, 36, 3, 3, 24, 1, 35, 2, 1, 0, 0),
    ('Match1', 'Ravindra Jadeja', 12, 10, 1, 0, 60, 3, 50, 2, 0, 0, 1),
    ('Match1', 'Jasprit Bumrah', 0, 0, 0, 0, 54, 2, 28, 3, 0, 0, 0),
    ('Match1', 'Bhuvneshwar Kumar', 15, 12, 2, 0, 60, 1, 46, 2, 0, 0, 0),
]

conn = db.get_connection()
cur = conn.cursor()
cur.executemany(
    'INSERT INTO match (name, player, scored, faced, fours, sixes, bowled, maiden, given, wkts, catches, stumping, run_out) '
    'VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
    rows
)
conn.commit()
conn.close()
print('Inserted', len(rows), 'rows into match table.')
