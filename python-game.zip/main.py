import pygame
import sys
from game import Game

# Initialize Pygame
pygame.init()

# Constants
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
FPS = 60

# Set up the display
screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Python Game")
clock = pygame.time.Clock()

# Create game instance
game = Game(screen)

# Main game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            sys.exit()
        
        # Handle other game events
        game.handle_events(event)
    
    # Update game state
    game.update()
    
    # Draw everything
    game.draw()
    
    # Update display
    pygame.display.flip()
    clock.tick(FPS)
