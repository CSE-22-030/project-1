# Python Game Project

A Python-based game project using Pygame framework.

## Requirements
- Python 3.8+
- pygame==2.5.2
- numpy==1.24.3
- pillow==10.0.0

## Setup
1. Install requirements:
   ```
   pip install -r requirements.txt
   ```

2. Run the game:
   ```
   python main.py
   ```

## Project Structure
- `main.py`: Main game entry point
- `game/`: Game logic and components
- `assets/`: Game assets (images, sounds)
- `utils/`: Utility functions
